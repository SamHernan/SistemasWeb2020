document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("formulario").addEventListener('submit', validarFormulario); 
  });
  
  function validarFormulario(evento) {
    evento.preventDefault();
    var usuario = document.getElementById('usuario').value;
    if(usuario.length == 0) {
      alert('Campo de Usuario vacio');
      return;
    }
    var pass= document.getElementById('pass').value;
    if (pass.length < 6) {
      alert('La clave no es válida');
      return;
    }
    this.submit();
  }